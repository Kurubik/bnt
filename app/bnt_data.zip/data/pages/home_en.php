<?php
return array (

    'wideblock' => array(
        'background' => '/public/assets/images/home_wide_back.jpg',
        'title' => 'Ecologically friendly<br>fuel production in Latvia',
        'subtitle' => 'explore the project',
        'link' => '',
        'quarterblock' => array(
            'text' => 'Erspernat doloreicia veritio ratio. Dem con ea pre dignihit, offictem quam con nissinis rerovit.',
            'image' => '/public/assets/images/baltic_ecofuel.png',
        ),
    ),

);